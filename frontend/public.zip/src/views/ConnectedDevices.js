import React, { useState, useEffect } from 'react';
import mqtt from 'mqtt'; // Pokud používáte mqtt.js

const ConnectedDevices = ({ handleBack }) => {
    const [devices, setDevices] = useState([]); // Seznam zařízení
    const mqttClient = React.useRef(null);

    useEffect(() => {
        // Připojení k MQTT brokeru
        mqttClient.current = mqtt.connect('mqtt://broker-url:port'); // Nahraďte URL brokeru
        mqttClient.current.on('connect', () => {
            console.log('MQTT připojeno');
            mqttClient.current.subscribe('devices/status'); // Přihlášení k tématu
        });

        mqttClient.current.on('message', (topic, message) => {
            if (topic === 'devices/status') {
                const deviceData = JSON.parse(message.toString());
                setDevices((prevDevices) => {
                    // Aktualizace seznamu zařízení
                    const index = prevDevices.findIndex(d => d.id === deviceData.id);
                    if (index !== -1) {
                        const updatedDevices = [...prevDevices];
                        updatedDevices[index] = deviceData;
                        return updatedDevices;
                    }
                    return [...prevDevices, deviceData];
                });
            }
        });

        return () => {
            // Odpojení od MQTT při odpojení komponenty
            mqttClient.current.end();
        };
    }, []);

    const handleDeviceCommand = (deviceId, command) => {
        // Publikace příkazu zařízení přes MQTT
        mqttClient.current.publish(`devices/${deviceId}/command`, command);
    };

    return (
        <div>
            <h2>Seznam připojených zařízení</h2>
            {devices.length === 0 ? (
                <p>Načítám seznam zařízení...</p>
            ) : (
                <ul className="list-group mb-3">
                    {devices.map((device) => (
                        <li
                            key={device.id}
                            className="list-group-item d-flex justify-content-between align-items-center"
                        >
                            <div>
                                <strong>{device.name}</strong> <br />
                                Stav: {device.status === 'on' ? 'Zapnuto' : 'Vypnuto'}
                            </div>
                            <div>
                                <button
                                    className="btn btn-success btn-sm me-2"
                                    onClick={() => handleDeviceCommand(device.id, 'on')}
                                >
                                    Zapnout
                                </button>
                                <button
                                    className="btn btn-danger btn-sm"
                                    onClick={() => handleDeviceCommand(device.id, 'off')}
                                >
                                    Vypnout
                                </button>
                            </div>
                        </li>
                    ))}
                </ul>
            )}
            <button className="btn btn-secondary w-100" onClick={handleBack}>
                Zpět
            </button>
        </div>
    );
};

export default ConnectedDevices;
