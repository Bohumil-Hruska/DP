import React from 'react';
import {
    FaLightbulb,
    FaThermometerHalf,
    FaShieldAlt,
    FaVideo,
    FaPowerOff,
    FaLock,
    FaHome,
    FaThLarge,
    FaChartBar,
    FaCogs
} from 'react-icons/fa';

const ResponsiveSmartDashboard = () => {
    const rooms = ['Living Room', 'Kitchen', 'Bedroom', 'Bathroom'];

    const devices = [
        {
            name: 'Lights',
            icon: <FaLightbulb style={{ color: '#FFD700', fontSize: '1.5rem' }} />,
            status: 'On',
        },
        {
            name: 'Climate',
            icon: <FaThermometerHalf style={{ color: '#00BFFF', fontSize: '1.5rem' }} />,
            status: '21,5°C',
        },
        {
            name: 'Security',
            icon: <FaShieldAlt style={{ color: '#4682B4', fontSize: '1.5rem' }} />,
            status: 'Armed',
        },
        {
            name: 'Camera',
            icon: <FaVideo style={{ color: '#A9A9A9', fontSize: '1.5rem' }} />,
            status: '1 detected',
        },
    ];

    return (
        <div className="container-fluid bg-dark text-white min-vh-100 py-4 px-3">
            {/* Header */}
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="mb-0">Home</h2>
                <FaCogs style={{ fontSize: '1.5rem' }} />
            </div>

            {/* Rooms */}
            <h5 className="mb-3">Rooms</h5>
            <div className="row g-3 mb-4">
                {rooms.map((room, index) => (
                    <div className="col-6 col-md-3" key={index}>
                        <div className="card bg-secondary text-white text-center">
                            <div className="card-body py-3">{room}</div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Devices */}
            <h5 className="mb-3">Devices</h5>
            <div className="row g-3 mb-4">
                {devices.map((device, index) => (
                    <div className="col-6 col-md-3" key={index}>
                        <div className="card bg-secondary text-white text-center">
                            <div className="card-body">
                                <div className="mb-2">{device.icon}</div>
                                <div>{device.name}</div>
                                <small className="text-muted">{device.status}</small>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Automation */}
            <h5 className="mb-3">Automation</h5>
            <div className="row g-3 mb-5">
                <div className="col-12 col-md-6">
                    <button className="btn btn-outline-light w-100 d-flex align-items-center justify-content-center">
                        <FaPowerOff className="me-2" /> All Lights Off
                    </button>
                </div>
                <div className="col-12 col-md-6">
                    <button className="btn btn-outline-light w-100 d-flex align-items-center justify-content-center">
                        <FaLock className="me-2" /> Away Mode
                    </button>
                </div>
            </div>

            {/* Bottom navigation */}
            <div className="d-md-none fixed-bottom bg-black border-top border-secondary d-flex justify-content-around py-2">
                <div className="text-white text-center">
                    <FaHome size={20} />
                    <div className="small">Home</div>
                </div>
                <div className="text-muted text-center">
                    <FaThLarge size={20} />
                    <div className="small">Rooms</div>
                </div>
                <div className="text-muted text-center">
                    <FaChartBar size={20} />
                    <div className="small">Stats</div>
                </div>
                <div className="text-muted text-center">
                    <FaCogs size={20} />
                    <div className="small">Settings</div>
                </div>
            </div>
        </div>
    );
};

export default ResponsiveSmartDashboard;
